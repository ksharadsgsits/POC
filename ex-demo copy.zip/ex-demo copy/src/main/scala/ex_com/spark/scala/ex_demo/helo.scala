import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf


object sparkParquetFile {
  def main (args: Array[String]):Unit = {
    val where_clause = args(0).toString // only for cluster mode
    //val where_clause="empid=1"

    val  spark= SparkSession.builder().master("local[*]").getOrCreate()
    val sc=spark.sparkContext
    val sqlContext=spark.sqlContext
    val parquetFileDF= spark.read.parquet("people.parquet")
    parquetFileDF.createOrReplaceTempView("parquetFile")
    val valueDF = spark.sql("SELECT * FROM parquetFile WHERE  " + where_clause)
    valueDF.show()
    valueDF.coalesce(1).write.option("header","true").csv("/Users/sharjain/testpoc.csv")
    spark.close()
  }
}
